솔루션 폴더 : OOD02_4_GoStop


컴파일 방법 : main함수를 실행한다.

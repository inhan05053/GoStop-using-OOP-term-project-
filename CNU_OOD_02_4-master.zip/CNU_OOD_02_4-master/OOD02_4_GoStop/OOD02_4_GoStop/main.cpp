#include "GoStop.h"
#include <time.h>
int main() {
  srand((unsigned)time(0));
  GoStop go;
  go.Play();
}